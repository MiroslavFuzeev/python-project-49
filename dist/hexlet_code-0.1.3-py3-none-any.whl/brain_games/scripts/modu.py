def module():
    print('success')
