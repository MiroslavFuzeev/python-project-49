import modu

def test():
    print(modu.module())

print(test())
