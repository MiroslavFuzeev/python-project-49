#!/usr/bin/env python3

import prompt

welcome_user = prompt.string('May I have your name? ')
